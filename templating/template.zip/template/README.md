# Jetty Web Application Template

This directory contains a template for creating and running servlets
and the Apache FreeMarker Template engine via the embedded Jetty engine.

To run the server:

mvn jetty:run
