# Jetty Web Application Template

This directory contains a template for creating and running servlets
via the embedded Jetty engine.

To run the server:

mvn jetty:run
